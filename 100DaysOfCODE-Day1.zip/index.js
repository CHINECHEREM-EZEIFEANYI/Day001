var x; //indicating what variable to use
    console.log(`Even numbers from 2 to 10 are:`)
//using for loop for iteration
for (x = 2; x <= 10; x++) { 
  if (x % 2 == 0) { //conditional statement
 console.log(`${x}`);
}
}





